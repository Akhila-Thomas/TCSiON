package StepDefinitions;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SupplierLogin {

	WebDriver driver=null;
	
	@Given("open Chrome and navigate to Supplier Login page")
	public void open_chrome_and_navigate_to_supplier_login_page() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/api/supplier");
		Thread.sleep(3000);
	}

	@When("supplier enters valid username and password")
	public void supplier_enters_valid_username_and_password() {
	   
		driver.findElement(By.name("email")).sendKeys("supplier@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demosupplier");
	}

	@And("user clicks on login button")
	public void user_clicks_on_login_button() throws InterruptedException {
	    
		driver.findElement(By.xpath("//span[text()='Login']")).click(); 
		Thread.sleep(5000);
		
	}

	@Then("user should navigated to supplier dashboard")
	public void user_should_navigated_to_supplier_dashboard() {
	    
		driver.findElement(By.xpath("//h1[text()='Dashboard']")).isDisplayed();
		driver.quit();
		
		
	}

}
