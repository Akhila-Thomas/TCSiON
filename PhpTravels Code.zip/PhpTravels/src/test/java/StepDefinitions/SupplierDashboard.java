package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SupplierDashboard {

	WebDriver driver=null;
	
	@Given("Open Chrome and user is in Supplier Login page")
	public void open_chrome_and_user_is_in_supplier_login_page() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/api/supplier");
		Thread.sleep(3000);
	}

	@Then("user logged-in to supplier home page")
	public void user_logged_in_to_supplier_home_page() throws InterruptedException {
	    
		driver.findElement(By.name("email")).sendKeys("supplier@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demosupplier");
	    driver.findElement(By.xpath("//span[text()='Login']")).click();
	    Thread.sleep(5000);
	}

	@SuppressWarnings("deprecation")
	@When("user clicks on Dashboard")
	public void user_clicks_on_dashboard() {
	    
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[text()='Dashboard']")).click(); 
		
	}

	@SuppressWarnings("deprecation")
	@Then("user should see the text Sales overview & summary in the dashboard")
	public void user_should_see_the_text_sales_overview_summary_in_the_dashboard() {
	    
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[text()='Sales overview & summary']")).isDisplayed();
		driver.quit();
	}
}
