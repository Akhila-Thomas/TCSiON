package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentLinksTest {

	WebDriver driver=null;
	
	@SuppressWarnings("deprecation")
	@Given("Open Chrome and user is in agent dashboard")
	public void open_chrome_and_user_is_in_agent_dashboard() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demoagent");
	    driver.findElement(By.xpath("//button[@type='submit' and @class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")).click(); 
		Thread.sleep(3000);
	}

	@When("user clicks on MyBookings")
	public void user_clicks_on_my_bookings() {
	    
		driver.findElement(By.xpath("//a[text()=' My Bookings' and @class=' waves-effect']")).click();
		
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to my_bookings page")
	public void user_should_navigate_to_my_bookings_page() {
	    
		String BURL=driver.getCurrentUrl();
		Assert.assertEquals(BURL, "https://phptravels.net/account/bookings");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@When("user clicks on AddFunds")
	public void user_clicks_on_add_funds() {
	    
		driver.findElement(By.xpath("//a[text()=' Add Funds' and @class=' waves-effect']")).click();
		
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to Add_Funds page")
	public void user_should_navigate_to_add_funds_page() {
	    
		String FURL=driver.getCurrentUrl();
		Assert.assertEquals(FURL, "https://phptravels.net/account/add_funds");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		
	}

	@When("user clicks on MyProfile")
	public void user_clicks_on_my_profile() {
		
		driver.findElement(By.xpath("//a[text()=' My Profile' and @class=' waves-effect']")).click();
		
	}
	@SuppressWarnings("deprecation")
	@Then("user should navigate to My_Profile page")
	public void user_should_navigate_to_my_profile_page() {
	    
		String BURL=driver.getCurrentUrl();
		Assert.assertEquals(BURL, "https://phptravels.net/account/profile");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@When("user clicks on Logout button")
	public void user_clicks_on_logout_button() {
	    
		driver.findElement(By.xpath("//a[text()=' Logout' and @class=' waves-effect']")).click();
		
	}

	@Then("user should logged-out and return to login page")
	public void user_should_logged_out_and_return_to_login_page() {
	    
		String BURL=driver.getCurrentUrl();
		Assert.assertEquals(BURL, "https://phptravels.net/login");
		driver.quit();
	}

}
