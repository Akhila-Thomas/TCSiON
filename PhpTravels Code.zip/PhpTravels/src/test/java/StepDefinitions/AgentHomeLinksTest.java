package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentHomeLinksTest {

	WebDriver driver=null;
	
	@SuppressWarnings("deprecation")
	@Given("Open Chrome and user is in agent dashboard for testing links")
	public void open_chrome_and_user_is_in_agent_dashboard_for_testing_links() throws InterruptedException {
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demoagent");
	    driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//button[@type='submit' and @class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")).click(); 
		Thread.sleep(3000);
	}
	
	
	@When("user clicks on Home icon")
	public void user_clicks_on_home_icon() {
	    
		driver.findElement(By.xpath("//a[ @href='https://phptravels.net/' and @class=' waves-effect']")).click();
		
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to home page")
	public void user_should_navigate_to_home_page() {
	    
		String HURL=driver.getCurrentUrl();
		Assert.assertEquals(HURL, "https://phptravels.net/");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@When("user clicks on Hotels link")
	public void user_clicks_on_hotels_link() {
	    
		driver.findElement(By.xpath("//a[@title='hotels']")).click();
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to hotels page")
	public void user_should_navigate_to_hotels_page() {
	    
		String HOURL=driver.getCurrentUrl();
		Assert.assertEquals(HOURL, "https://phptravels.net/hotels");
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	}

	@When("user clicks on Flights link")
	public void user_clicks_on_flights_link() {
	    
		driver.findElement(By.xpath("//a[@title='flights']")).click();
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to flights page")
	public void user_should_navigate_to_flights_page() {
	    
		String FURL=driver.getCurrentUrl();
		Assert.assertEquals(FURL, "https://phptravels.net/flights");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@When("user clicks on Tours link")
	public void user_clicks_on_tours_link() {
	    
		driver.findElement(By.xpath("//a[@title='tours']")).click();
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to tours page")
	public void user_should_navigate_to_tours_page() {
	    
		String TURL=driver.getCurrentUrl();
		Assert.assertEquals(TURL, "https://phptravels.net/tours");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@When("user clicks on Visa link")
	public void user_clicks_on_visa_link() {


		driver.findElement(By.xpath("//a[@title='visa']")).click();
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to visa page")
	public void user_should_navigate_to_visa_page() {

		String VURL=driver.getCurrentUrl();
		Assert.assertEquals(VURL, "https://phptravels.net/visa");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		
	}

	@When("user clicks on Blog link")
	public void user_clicks_on_blog_link() {
	    
		driver.findElement(By.xpath("//a[@title='blog']")).click();
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to blog page")
	public void user_should_navigate_to_blog_page() {
	    
		String BLURL=driver.getCurrentUrl();
		Assert.assertEquals(BLURL, "https://phptravels.net/blog");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@When("user clicks on Offers link")
	public void user_clicks_on_offers_link() {
	    
		driver.findElement(By.xpath("//a[@title='offers']")).click();
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to offers page")
	public void user_should_navigate_to_offers_page() {
	    
		String OFURL=driver.getCurrentUrl();
		Assert.assertEquals(OFURL, "https://phptravels.net/offers");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.quit();
	}
	

	
	
}
