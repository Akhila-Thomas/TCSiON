package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdminLogin {
	
	WebDriver driver=null;

	@Given("Open Chrome and navigate to Php travels Admin Login page")
	public void open_chrome_and_navigate_to_php_travels_admin_login_page() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/api/admin");
		Thread.sleep(3000);
	}

	@When("admin user enters valid username and password")
	public void admin_user_enters_valid_username_and_password() {
	    
		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demoadmin");
		
	}

	@SuppressWarnings("deprecation")
	@And("clicks on login button in admin login page")
	public void clicks_on_login_button_in_admin_login_page() {
	    
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//span[text()='Login']")).click();
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigated to admin homepage")
	public void user_should_navigated_to_admin_homepage() {
	    
		String HURL=driver.findElement(By.xpath("//h1[text()='Dashboard']")).getText();
		Assert.assertEquals(HURL, "Dashboard");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//button[@id='dropdownMenuProfile']")).click();
		driver.findElement(By.xpath("//div[text()='Logout']")).click();
		
	}

	@When("admin user enters invalid username and password")
	public void admin_user_enters_invalid_username_and_password() {
	    
		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demo");
	}

	@SuppressWarnings("deprecation")
	@And("clicks on login button in the AdminLogin page")
	public void clicks_on_login_button_in_the_admin_login_page() {
	    
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//span[text()='Login']")).click();
	}

	@Then("user see an error message for invalid login credentials")
	public void user_see_an_error_message_for_invalid_login_credentials() {
	    
		//String URL=driver.findElement(By.xpath("//div[text()='Invalid Login Credentials']")).getText();
		//Assert.assertEquals(URL, "Invalid Login Credentials");
		driver.findElement(By.xpath("//div[text()='Invalid Login Credentials']")).isDisplayed();
		driver.quit();
		
	}

}
