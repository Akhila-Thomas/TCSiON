package StepDefinitions;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class VerifyBookings {

	
	WebDriver driver=null;
	
	@Given("Browser is open")
	public void browser_is_open() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(5000);
	}

	@Given("user is in dashboard of phptravels")
	public void user_is_in_dashboard_of_phptravels() throws InterruptedException {
	 
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demouser");
	    driver.findElement(By.xpath("//button[@type='submit' and @class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")).click(); 
		Thread.sleep(3000);
		
	}

	@When("user clicks on My Bookings icon")
	public void user_clicks_on_my_bookings_icon() {
	    
		driver.findElement(By.xpath("//a[text()=' My Bookings' and @class=' waves-effect']")).click();
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to My Bookings")
	public void user_should_navigate_to_my_bookings() {
	    
		//String BURL=driver.getCurrentUrl();
		//Assert.assertEquals(BURL, "https://phptravels.net/account/bookings");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	
	@When("user clicks on View Voucher button")
	public void user_clicks_on_view_voucher_button() {
	 
		driver.findElement(By.xpath("//a[text()=' View Voucher']")).click();
		
	}

	@Then("user should navigate to Booking Invoice page")
	public void user_should_navigate_to_booking_invoice_page() throws InterruptedException {
		
		ArrayList<String> tabs= new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		
		driver.findElement(By.xpath("//strong[text()='Reservation Number:']")).isDisplayed();
		Thread.sleep(2000);
		
		driver.close();
		driver.switchTo().window(tabs.get(0));
		Thread.sleep(2000);
		driver.quit();	
		//driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		//driver.findElement(By.xpath("//strong[text()='Reservation Number:']")).isDisplayed();
		
	}

	
}
