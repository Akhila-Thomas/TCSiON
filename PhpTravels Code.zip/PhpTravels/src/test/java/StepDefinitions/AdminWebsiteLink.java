package StepDefinitions;

import java.util.ArrayList;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdminWebsiteLink {

	
	WebDriver driver=null;
	
	@Given("Open Chrome and user is navigated to Admin Login page")
	public void open_chrome_and_user_is_navigated_to_admin_login_page() throws InterruptedException {
	   
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/api/admin");
		Thread.sleep(3000);
	}

	@When("adminuser enters valid username and password")
	public void adminuser_enters_valid_username_and_password() {
	    
		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demoadmin");
	}

	@SuppressWarnings("deprecation")
	@And("click on login button and enters to homepage")
	public void click_on_login_button_and_enters_to_homepage() {
	    
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//span[text()='Login']")).click();
	}

	@When("user clicks on website link")
	public void user_clicks_on_website_link() throws InterruptedException {
	    
		driver.findElement(By.xpath("//a[text()='Website']")).click();
		Thread.sleep(5000);
		
	}


	@Then("user should navigate to a different page")
	public void user_should_navigate_to_a_different_page() throws InterruptedException {
	    
		ArrayList<String> tabs= new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		
		driver.findElement(By.xpath("//strong[text()=' Let’s book your next trip!']")).isDisplayed();
		Thread.sleep(2000);
		
		driver.close();
		driver.switchTo().window(tabs.get(0));
		Thread.sleep(2000);
		driver.quit();	
		
	}
}
