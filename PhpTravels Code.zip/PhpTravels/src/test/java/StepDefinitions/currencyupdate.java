package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class currencyupdate {

WebDriver driver=null;
	
	@SuppressWarnings("deprecation")
	@Given("Open Chrome and user is in agent dashboard for update currency")
	public void open_chrome_and_user_is_in_agent_dashboard_for_update_currency() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demoagent");
	    driver.findElement(By.xpath("//button[@type='submit' and @class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")).click(); 
		Thread.sleep(5000);
	}

	@When("user clicks on USD")
	public void user_clicks_on_usd() throws InterruptedException {
	    
		driver.findElement(By.id("currency")).click();
		Thread.sleep(2000);
		
		
	}

	@Then("user should able to select the currency INR from list")
	public void user_should_able_to_select_the_currency_inr_from_list() throws InterruptedException {
	    
		driver.findElement(By.xpath("//a[text()=' INR']")).click();
		Thread.sleep(2000);
		driver.quit();
	}
	
}
