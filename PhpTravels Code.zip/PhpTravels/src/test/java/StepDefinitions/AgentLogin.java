package StepDefinitions;

import java.util.concurrent.TimeUnit;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentLogin {

	
	WebDriver driver=null;
	
	@Given("Open Chrome and navigate to Php travels Login page")
	public void open_chrome_and_navigate_to_php_travels_login_page() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(3000);
	}
	
	
	@When("user enters username and password")
	public void user_enters_username_and_password() throws InterruptedException {
	    
		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demoagent");
	    
	}
	@SuppressWarnings("deprecation")
	@And("clicks on login button")
	public void clicks_on_login_button() throws InterruptedException {
	   
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//span[text()='Login']")).click(); 
		
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigated to agent dashboard")
	public void user_should_navigated_to_agent_dashboard() {
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		//Alert alert=driver.switchTo().alert();
		//alert.accept();
		//https://phptravels.net/login/failed
		String URL=driver.getCurrentUrl();
		Assert.assertEquals(URL, "https://phptravels.net/account/dashboard");
		driver.quit();
	}

}
