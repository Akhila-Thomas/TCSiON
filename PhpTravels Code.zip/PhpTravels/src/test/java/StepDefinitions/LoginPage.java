package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
public class LoginPage {

	WebDriver driver=null;
	
	@Given("open Chrome and navigate to Login page")
	public void open_chrome_and_navigate_to_login_page() throws InterruptedException {
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(3000);
		
	}

	@When("valid username and password is entered")
	public void valid_username_and_password_is_entered() {
	    
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demouser");
	}

	@And("click on login button")
	public void click_on_login_button() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[text()='Login']")).click(); 
		Thread.sleep(5000);
		
	}

	@Then("user should navigated to dashboard")
	public void user_should_navigated_to_dashboard() {
	    
		String URL=driver.getCurrentUrl();
		Assert.assertEquals(URL, "https://phptravels.net/account/dashboard");
		driver.quit();
	}
}
