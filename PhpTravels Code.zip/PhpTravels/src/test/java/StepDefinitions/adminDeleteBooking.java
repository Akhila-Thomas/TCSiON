package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class adminDeleteBooking {

	WebDriver driver=null;
	
	@Given("Open Chrome and admin is in Admin Dashboard Page")
	public void open_chrome_and_admin_is_in_admin_dashboard_page() throws InterruptedException {
	   
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/api/admin");
		Thread.sleep(3000);
		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demoadmin");
	    driver.findElement(By.xpath("//span[text()='Login']")).click();
	    Thread.sleep(5000);
	}

	@SuppressWarnings("deprecation")
	@When("admin clicks on Cancelled Bookings link in the dashboard")
	public void admin_clicks_on_cancelled_bookings_link_in_the_dashboard() {
	    
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[text()='Dashboard']")).click(); 
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[text()='Cancelled Bookings']")).click(); 
	}

	@SuppressWarnings("deprecation")
	@Then("admin should navigate to Cancelled Bookings page")
	public void admin_should_navigate_to_cancelled_bookings_page() {
	    
		String PURL=driver.getCurrentUrl();
		Assert.assertEquals(PURL, "https://phptravels.net/api/admin/bookings/cancelled");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@When("admin click on delete record red button")
	public void admin_click_on_delete_record_red_button() throws InterruptedException {
	   
		driver.findElement(By.xpath("//button[@class='btn btn-danger mdc-ripple-upgraded']")).click();
		Alert alert=driver.switchTo().alert();
		alert.accept();
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@Then("record should delete and admin come back to dashboard to count the cancelled booking")
	public void record_should_delete_and_admin_come_back_to_dashboard_to_count_the_cancelled_booking() {
	    
		driver.findElement(By.xpath("//div[text()='Dashboard']")).click(); 
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.quit();
	}

}
