package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SupplierLinksTest {

	WebDriver driver=null;
	
	@Given("Open Chrome and Supplier is in Login page")
	public void open_chrome_and_supplier_is_in_login_page() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/api/supplier");
		Thread.sleep(3000);
	}


	@Then("supplier logged-in to supplier home page")
	public void supplier_logged_in_to_supplier_home_page() throws InterruptedException {
	    
		driver.findElement(By.name("email")).sendKeys("supplier@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demosupplier");
	    driver.findElement(By.xpath("//span[text()='Login']")).click();
	    Thread.sleep(5000);
	}

	@Then("supplier test Tours link is displayed")
	public void supplier_test_tours_link_is_displayed() {
		
		driver.findElement(By.xpath("//a[@aria-controls='toursmodule']")).isDisplayed();
		
	}   

	@SuppressWarnings("deprecation")
	@And("supplier clicks on Tours link")
	public void supplier_clicks_on_tours_link() {
	   
		driver.findElement(By.xpath("//a[@aria-controls='toursmodule']")).click(); 
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@Then("supplier should see tours menu")
	public void supplier_should_see_tours_menu() {
	    
		driver.findElement(By.xpath("//div[@id='Tours']")).isDisplayed();
		System.out.println("Tours link is present");
	}

	@When("supplier test Bookings link is displayed")
	public void supplier_test_bookings_link_is_displayed() {
	   
		driver.findElement(By.xpath("//i[text()='receipt']")).isDisplayed();
		System.out.println("Bookings link is displayed");
		
	}

	@And("supplier clicks on Bookings link")
	public void supplier_clicks_on_bookings_link() throws InterruptedException {
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("//i[text()='receipt']")).click();
		
	}

	@SuppressWarnings("deprecation")
	@Then("supplier should navigated to bookings page")
	public void supplier_should_navigated_to_bookings_page() {
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		String URL=driver.getCurrentUrl();
		Assert.assertEquals(URL, "https://phptravels.net/api/supplier/bookings");
		driver.quit();
		
	}

}
