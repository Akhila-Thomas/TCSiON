package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Payment {

	WebDriver driver=null;
	
	@Given("browser is open and user is in phptravels login page")
	public void browser_is_open_and_user_is_in_phptravels_login_page() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(5000);
	}

	@And("user is logged-in and enters into dashboard")
	public void user_is_logged_in_and_enters_into_dashboard() throws InterruptedException {
	   
		
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demouser");
	    driver.findElement(By.xpath("//button[@type='submit' and @class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")).click(); 
		Thread.sleep(3000);
		
	}

	@When("user clicks on Add Funds to pay the amount")
	public void user_clicks_on_add_funds_to_pay_the_amount() {
	    
		driver.findElement(By.xpath("//a[text()=' Add Funds' and @class=' waves-effect']")).click();
		
	}

	
	@SuppressWarnings("deprecation")
	@Then("user should navigate to Add Funds Page")
	public void user_should_navigate_to_add_funds_page() {
	    
		String FURL=driver.getCurrentUrl();
		Assert.assertEquals(FURL, "https://phptravels.net/account/add_funds");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scroll(0,350)");
	}

	@SuppressWarnings("deprecation")
	@When("user select pay with Paypal payment method")
	public void user_select_pay_with_paypal_payment_method() {
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@name='payment_gateway' and @id='gateway_paypal']")).click();

	}

	@And("user enters amount")
	public void user_enters_amount() {
	    
		driver.findElement(By.name("price")).clear();
		driver.findElement(By.name("price")).sendKeys("50");
		
	}

	@SuppressWarnings("deprecation")
	@And("clicks on Pay now button")
	public void clicks_on_pay_now_button() {
	    
		driver.findElement(By.xpath("//button[text()='Pay Now ']")).click();
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		
	}
	
	@SuppressWarnings("deprecation")
	@Then("user should navigate to payment with paypal page")
	public void user_should_navigate_to_payment_with_paypal_page() {
	    
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//small[text()='Pay With ']")).isDisplayed();
		driver.quit();
	}

}
