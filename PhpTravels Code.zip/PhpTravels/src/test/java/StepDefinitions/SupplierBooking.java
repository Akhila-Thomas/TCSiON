package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SupplierBooking {

	WebDriver driver=null;
	
	@Given("Open Chrome and user1 is in Supplier Dashboard")
	public void open_chrome_and_user1_is_in_supplier_dashboard() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/api/supplier");
		Thread.sleep(3000);
		driver.findElement(By.name("email")).sendKeys("supplier@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demosupplier");
	    driver.findElement(By.xpath("//span[text()='Login']")).click();
	    Thread.sleep(5000);
	}

	@SuppressWarnings("deprecation")
	@When("user1 clicks on Pending Bookings link in the dashboard")
	public void user1_clicks_on_pending_bookings_link_in_the_dashboard() {
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[text()='Dashboard']")).click(); 
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[text()='Pending Bookings']")).click(); 
	}

	@SuppressWarnings("deprecation")
	@Then("user1 should navigate to Pending Bookings page")
	public void user1_should_navigate_to_pending_bookings_page() {
	    
		String PURL=driver.getCurrentUrl();
		Assert.assertEquals(PURL, "https://phptravels.net/api/supplier/bookings/pending");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@Then("user1 click on Booking status")
	public void user1_click_on_booking_status() {
	    
		driver.findElement(By.id("booking_status")).click();
		
	}

	@And("change the status from Pending to Confirmed")
	public void change_the_status_from_pending_to_confirmed() throws InterruptedException {
	    
		driver.findElement(By.xpath("//option[text()='Confirmed']")).click();
		Thread.sleep(5000);
		
	}

	
	@SuppressWarnings("deprecation")
	@Then("user1 come back to dashboard to count the booking")
	public void user1_come_back_to_dashboard_to_count_the_booking() {
	    
		driver.findElement(By.xpath("//div[text()='Dashboard']")).click(); 
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.quit();
	}

}
