package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SupplierRevenue {

	WebDriver driver=null;
	
	@Given("Open Chrome and user is in Supplier Dashboard")
	public void open_chrome_and_user_is_in_supplier_dashboard() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/api/supplier");
		Thread.sleep(3000);
		driver.findElement(By.name("email")).sendKeys("supplier@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demosupplier");
	    driver.findElement(By.xpath("//span[text()='Login']")).click();
	    Thread.sleep(5000);
	}

	@SuppressWarnings("deprecation")
	@When("user clicks on the Dashboard icon")
	public void user_clicks_on_the_dashboard_icon() {
	   
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[text()='Dashboard']")).click(); 
	}

	@SuppressWarnings("deprecation")
	@Then("user should see the text Revenue Breakdown in the dashboard")
	public void user_should_see_the_text_revenue_breakdown_in_the_dashboard() {
	    
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//h2[text()='Revenue Breakdown 2023']")).isDisplayed();
		driver.quit();
	}
}
