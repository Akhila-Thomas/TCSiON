package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TestLinks {

	
	WebDriver driver=null;
	
	@Given("browser is open")
	public void browser_is_open() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(5000);
		
	}

	@And("user is in dashboard")
	public void user_is_in_dashboard() throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demouser");
	    driver.findElement(By.xpath("//button[@type='submit' and @class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")).click(); 
		Thread.sleep(3000);
		
		
	}

	@When("user clicks on My Bookings")
	public void user_clicks_on_my_bookings() {
	    
		driver.findElement(By.xpath("//a[text()=' My Bookings' and @class=' waves-effect']")).click();
		
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to my bookings page")
	public void user_should_navigate_to_my_bookings_page() {
	   
		String BURL=driver.getCurrentUrl();
		Assert.assertEquals(BURL, "https://phptravels.net/account/bookings");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@When("user clicks on Add Funds")
	public void user_clicks_on_add_funds() {
	    
		driver.findElement(By.xpath("//a[text()=' Add Funds' and @class=' waves-effect']")).click();
		
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to Add Funds page")
	public void user_should_navigate_to_add_funds_page() {
	    
		String FURL=driver.getCurrentUrl();
		Assert.assertEquals(FURL, "https://phptravels.net/account/add_funds");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		
		
	}

	@When("user clicks on My Profile")
	public void user_clicks_on_my_profile() {
	    
		driver.findElement(By.xpath("//a[text()=' My Profile' and @class=' waves-effect']")).click();
		
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to My Profile page")
	public void user_should_navigate_to_my_profile_page() {
	    
		String BURL=driver.getCurrentUrl();
		Assert.assertEquals(BURL, "https://phptravels.net/account/profile");
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
	}

	@When("user clicks on logout")
	public void user_clicks_on_logout() {
	   
		driver.findElement(By.xpath("//a[text()=' Logout' and @class=' waves-effect']")).click();
		
	}

	@Then("user should logged out and navigate to login page")
	public void user_should_logged_out_and_navigate_to_login_page() {
	    
		String BURL=driver.getCurrentUrl();
		Assert.assertEquals(BURL, "https://phptravels.net/login");
		driver.quit();
		
	}


}
