package StepDefinitions;

import java.util.concurrent.TimeUnit;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentHotelSearch {

	WebDriver driver=null;
	
	@SuppressWarnings("deprecation")
	@Given("Open Chrome and user is in agent dashboard for searching hotels")
	public void open_chrome_and_user_is_in_agent_dashboard_for_searching_hotels() throws InterruptedException {
	    
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
	    driver.findElement(By.name("password")).sendKeys("demoagent");
	    driver.findElement(By.xpath("//button[@type='submit' and @class='btn btn-default btn-lg btn-block effect ladda-button waves-effect']")).click(); 
		Thread.sleep(3000);
	}

	@When("user clicks on Hotels icon")
	public void user_clicks_on_hotels_icon() {
	    
		driver.findElement(By.xpath("//a[@title='hotels']")).click();
	}

	@SuppressWarnings("deprecation")
	@Then("user should navigate to Hotels Page for search")
	public void user_should_navigate_to_hotels_page_for_search() {
	    
		String HOURL=driver.getCurrentUrl();
		Assert.assertEquals(HOURL, "https://phptravels.net/hotels");
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	}
	
	@When("user enters a city name and select that city from the drop down list")
	public void user_enters_a_city_name_and_select_that_city_from_the_drop_down_list() throws InterruptedException {
	    
		driver.findElement(By.xpath("/html/body/section[1]/section/div/div/form/div/div/div[1]/div/div/div/span/span[1]/span/span[1]")).click();
		driver.findElement(By.xpath("/html/body/span/span/span[1]/input")).sendKeys("Mumb");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li[text()='Mumbai,India']")).click();
		Thread.sleep(1000);
	}

	@And("user clicks on search icon")
	public void user_clicks_on_search_icon() throws InterruptedException {
	    
		driver.findElement(By.xpath("//button[@id=\'submit\']")).click();
		Thread.sleep(1000);
		
	}

	@Then("user should see hotels in that selected city")
	public void user_should_see_hotels_in_that_selected_city() throws InterruptedException {
		
		driver.findElement(By.xpath("//h2[text()='Search Hotels in mumbai']")).isDisplayed();
		Thread.sleep(1000);
		driver.close();
		driver.quit();
	}
}
